package hola;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.asyncsql.AsyncSQLClient;
import io.vertx.ext.asyncsql.MySQLClient;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;

public class RestServer extends AbstractVerticle{
	
private AsyncSQLClient mySQLClient;
	
	public void start(Future<Void> startFuture) {
		JsonObject config = new JsonObject()
				.put("host", "localhost")
				.put("username", "root")
				.put("password", "root")
				.put("database", "dad")
				.put("port", 3306);
		mySQLClient = 
				MySQLClient.createShared(vertx, config);
		
		Router router = Router.router(vertx);
		vertx.createHttpServer().requestHandler(router).
			listen(8090, result -> {
				if (result.succeeded()) {
					System.out.println("Servidor database desplegado");
				}else {
					System.out.println("Error de despliegue");
				}
			});
		router.route().handler(BodyHandler.create());
		router.get("/sensorespir").handler(this::handleAllPIR);
		router.get("/finalescarrera").handler(this::handleAllFC);
		/*router.get("/products/:productID/info").handler(this::handleProduct);
		router.put("/products/:productID/:property").handler(this::handleProductProperty);
		*/
	}
	
	private void handleAllPIR(RoutingContext routingConext) {
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("SELECT * FROM sensorespir" , result -> {
					if (result.succeeded()) {
						String jsonResult = result.result().toJson().encodePrettily();
						routingConext.response().end(jsonResult);
					}else {
						System.out.println(result.cause().getMessage());
						routingConext.response().setStatusCode(400).end();
					}
					connection.result().close();
				});
			}else {
				routingConext.response().end();
				connection.result().close();
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
	
	private void handleAllFC(RoutingContext routingConext) {
		mySQLClient.getConnection(connection -> {
			if (connection.succeeded()) {
				connection.result().query("SELECT * FROM finalescarrera" , result -> {
					if (result.succeeded()) {
						Integer cerrado = result.result().toJson().getInteger("cerrado?");
						String value;
						if(cerrado==1){
							value="Puerta cerrada";
						}else{
							value="Puerta abierta";
						}
						
						JsonObject jsonResult=result.result().toJson().put("cerrado?", value);
						routingConext.response().end(jsonResult.encodePrettily());
					}else {
						System.out.println(result.cause().getMessage());
						routingConext.response().setStatusCode(400).end();
					}
					connection.result().close();
				});
			}else {
				routingConext.response().end();
				connection.result().close();
				System.out.println(connection.cause().getMessage());
				routingConext.response().setStatusCode(400).end();
			}
		});
	}
	
	/*private void handleProduct(RoutingContext routingContext) {
		String paramStr = routingContext.pathParam("productID");
		int paramInt = Integer.parseInt(paramStr);
		JsonObject jsonObject = new JsonObject();
		jsonObject.put("serial", "asfas234ewsdcdwe24");
		jsonObject.put("id", paramInt);
		jsonObject.put("name", "TV Samsung");
		routingContext.response()
			.putHeader("content-type", "application/json")
			.end(jsonObject.encode());
	}
	
	private void handleProductProperty(RoutingContext routingContext) {
		//String paramStr = routingContext.pathParam("productID");
		//int paramInt = Integer.parseInt(paramStr);
		JsonObject body = routingContext.getBodyAsJson();
		// Petici�n BBDD
		routingContext.response()
		.putHeader("content-type", "application/json")
		.end(body.encode());
	}
	*/
}
