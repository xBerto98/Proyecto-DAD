package hola;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.json.JsonObject;

public class JsonExamples extends AbstractVerticle{
	public void start(Future<Void> startFuture){
		JsonObject jsonObject=new JsonObject();
		jsonObject.put("elem", "Object");
		jsonObject.put("elem1", "Object");
		jsonObject.put("elem2", "123");
		jsonObject.put("elem3", 123);
		jsonObject.put("elem4", "Object");
		System.out.println(jsonObject.encodePrettily());
		System.out.println(jsonObject.encode());
		
		JsonObject decode=new JsonObject(jsonObject.encode());
		System.out.println(decode.getString("elem2"));
		System.out.println(decode.getInteger("elem3"));
	}
}
