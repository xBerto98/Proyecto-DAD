package hola;

import io.vertx.core.Future;
import io.vertx.core.AbstractVerticle;

public class CommReciever extends AbstractVerticle{
	public void start(Future<Void> startFuture){
		vertx.eventBus()
		.consumer("mensaje peer-peer", //identificador
		          message->{           //handler para procesar mensaje
		        	  System.out.println(message.body().toString());
					  String response="VALE " + this.getClass().getName();
					  message.reply(response);
		          });
	}
}
