package hola;

import io.vertx.core.Future;
import io.vertx.core.AbstractVerticle;

public class CommRecieverBroadcast extends AbstractVerticle{
	public void start(Future<Void> startFuture){
		vertx.eventBus()
		.consumer("mensaje broadcast", //identificador
		          message->{           //handler para procesar mensaje
		        	  System.out.println("ME ESTOY CAGANDO " + message.body().toString());
		        	  //Al ser BROADCAST,no tiene sentido que haya respuesta
		        	  System.out.println("Si, te est�s cagando ");
		        });
	}
}
