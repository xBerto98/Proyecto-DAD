package hola;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.eventbus.EventBus;

public class CommSender extends AbstractVerticle{
	public void start(Future<Void> startFuture){
		EventBus eventBus=vertx.eventBus();
		//cada 2 segundos enviamos a trav�s del event bus
		vertx.setPeriodic(2000, tick->{
			//mensaje broadcast, env�a a todos, solo reciben quienes est�n suscritos a dicho msg.
			eventBus.publish("mensaje broadcast", "YO TAMBI�N"); //id y mensaje, sin handler
			//mensaje punto a punto, recibir/responder de un lado a otro
			eventBus.send("mensaje peer-peer", //identificador
					"ME ESTOY CAGANDO ENCIMA" //contenido
					,response->{ //handler para escuchar la respuesta
						if(response.succeeded()){
							System.out.println(response.result().body().toString()); //cuerpo del mensaje
						}else{
							System.out.println(response.cause().getMessage());
						}
					}); 
		});
	}

}
