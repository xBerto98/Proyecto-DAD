package hola;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;

public class Main extends AbstractVerticle{
	
	public void start(Future<Void> startFuture){
		//lanzar verticles en "paralelo"
		/*vertx.deployVerticle(new CommReciever());
		vertx.deployVerticle(new CommSender());
		vertx.deployVerticle(new CommRecieverBroadcast());
		vertx.deployVerticle(new JsonExamples());
		*/
		/*vertx.deployVerticle(new TcpServer());
		for(int i=0;i<10000;i++){
			vertx.deployVerticle(new TcpClient());
		}
		*/
		
		vertx.deployVerticle(new RestServer());
		
		//servidor HTTP
		/*vertx
		     .createHttpServer()
			 .requestHandler(r -> {
				 r
				 .response()
				 .end("<b>QUE PASO PARSERO</b>"); //c�digo HTML
			   })
			 .listen(8082, result-> { //startFuture informa sobre el estado del verticle
				 if(result.succeeded()){
					 System.out.println("Servidor desplegado");
					 startFuture.complete(); //comunicaci�n verticle-core de vertx
				 }else{
					 startFuture.fail(result.cause());
				 }
			 }); 
			 */
	}
	
}